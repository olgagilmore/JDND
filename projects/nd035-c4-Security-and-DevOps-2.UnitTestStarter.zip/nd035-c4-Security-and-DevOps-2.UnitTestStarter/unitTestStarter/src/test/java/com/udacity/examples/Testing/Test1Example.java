package com.udacity.examples.Testing;

import junit.framework.TestCase;

public class Test1Example extends TestCase {

}
